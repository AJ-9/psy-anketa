# 🚀 Настройка проекта на GitHub

## Шаг 1: Инициализация Git репозитория

```bash
cd /Users/alikbidzhiev/Documents/Cursor_Psy
git init
```

## Шаг 2: Добавление файлов

```bash
git add .
```

## Шаг 3: Первый коммит

```bash
git commit -m "Initial commit: PsyAnketa - психологическое анкетирование

- Расширенная анкета с 40+ вопросами
- Определение типа личности
- Анализ психологического состояния
- Генерация рекомендаций
- Сохранение в БД (Prisma + SQLite)
- Экспорт в PDF
- Панель психолога"
```

## Шаг 4: Создание репозитория на GitHub

1. Перейдите на https://github.com
2. Нажмите кнопку **"New repository"** (или **"+"** → **"New repository"**)
3. Заполните:
   - **Repository name:** `psy-anketa` (или любое другое имя)
   - **Description:** `Онлайн справочник-анкетирование для психолога`
   - **Visibility:** Выберите Public или Private
   - **НЕ** ставьте галочки на "Initialize with README", "Add .gitignore", "Choose a license"
4. Нажмите **"Create repository"**

## Шаг 5: Подключение к GitHub

После создания репозитория GitHub покажет инструкции. Выполните:

```bash
# Добавьте remote (замените YOUR_USERNAME на ваш GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/psy-anketa.git

# Или через SSH (если настроен):
# git remote add origin git@github.com:YOUR_USERNAME/psy-anketa.git

# Переименуйте ветку в main (если нужно)
git branch -M main

# Запушьте код
git push -u origin main
```

## Шаг 6: Проверка

Откройте ваш репозиторий на GitHub - там должен быть весь код проекта!

## Полезные команды Git

### Проверка статуса
```bash
git status
```

### Добавление изменений
```bash
git add .
# или конкретный файл
git add app/page.tsx
```

### Коммит изменений
```bash
git commit -m "Описание изменений"
```

### Отправка на GitHub
```bash
git push
```

### Получение обновлений
```bash
git pull
```

### Просмотр истории коммитов
```bash
git log --oneline
```

## Настройка .gitignore

Файл `.gitignore` уже настроен и исключает:
- `node_modules/` - зависимости
- `.next/` - сборка Next.js
- `*.db` - база данных
- `archives/` - архивы (опционально)
- `.env*.local` - локальные переменные окружения

## GitHub Actions

В проекте настроен GitHub Action для автоматического создания архивов при каждом push в main/master ветку.

Архивы будут доступны в разделе **Actions** → **Artifacts** вашего репозитория.

## Рекомендации

1. **Делайте коммиты часто** - после каждого значительного изменения
2. **Пишите понятные сообщения коммитов** - что и зачем изменилось
3. **Используйте ветки** для новых функций:
   ```bash
   git checkout -b feature/new-feature
   # ... делаете изменения ...
   git commit -m "Add new feature"
   git push origin feature/new-feature
   ```
4. **Не коммитьте**:
   - `node_modules/`
   - `.env` файлы с секретами
   - Базы данных
   - Временные файлы

## Проблемы?

### Ошибка "remote origin already exists"
```bash
git remote remove origin
git remote add origin https://github.com/YOUR_USERNAME/psy-anketa.git
```

### Ошибка аутентификации
Настройте GitHub CLI или используйте Personal Access Token:
1. GitHub → Settings → Developer settings → Personal access tokens
2. Создайте токен с правами `repo`
3. Используйте токен вместо пароля при push

### Изменить URL remote
```bash
git remote set-url origin https://github.com/YOUR_USERNAME/psy-anketa.git
```

