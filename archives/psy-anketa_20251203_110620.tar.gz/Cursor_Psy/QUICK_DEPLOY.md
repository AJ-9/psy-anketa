# 🚀 Быстрое развертывание онлайн

## Vercel (5 минут) ⭐

### 1. Перейдите на Vercel:
**https://vercel.com/new**

### 2. Войдите через GitHub:
Нажмите **"Continue with GitHub"**

### 3. Импортируйте проект:
- Выберите репозиторий: **`AJ-9/psy-anketa`**
- Нажмите **"Import"**

### 4. Настройки (оставьте по умолчанию):
- Framework Preset: **Next.js** (определится автоматически)
- Root Directory: **`./`**
- Build Command: **`npm run build`** (автоматически)
- Output Directory: **`.next`** (автоматически)

### 5. Нажмите **"Deploy"**

### 6. Готово! 🎉

Ваш проект будет доступен по адресу:
```
https://psy-anketa-xxx.vercel.app
```

---

## Автоматические обновления:

После каждого `git push` в GitHub, Vercel автоматически:
- ✅ Соберет проект
- ✅ Развернет новую версию
- ✅ Обновит сайт

---

## Настройка БД для продакшена:

Для работы БД в продакшене нужно использовать PostgreSQL вместо SQLite:

1. **Vercel Postgres** (бесплатно):
   - В Vercel Dashboard → Storage → Create Database → Postgres
   - Скопируйте `DATABASE_URL`
   - Добавьте в Environment Variables

2. **Или Supabase** (бесплатно):
   - https://supabase.com
   - Создайте проект
   - Скопируйте Connection String
   - Добавьте в Vercel Environment Variables как `DATABASE_URL`

3. **Обновите Prisma schema:**
   ```prisma
   datasource db {
     provider = "postgresql"  // вместо "sqlite"
     url      = env("DATABASE_URL")
   }
   ```

---

**После деплоя проект будет доступен онлайн 24/7!**

