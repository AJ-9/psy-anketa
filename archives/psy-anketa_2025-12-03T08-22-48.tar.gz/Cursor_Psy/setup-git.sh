#!/bin/bash

# Скрипт для настройки Git и первого коммита

echo "🔧 Настройка Git для проекта PsyAnketa"
echo ""

# Проверка Git
if ! command -v git &> /dev/null; then
    echo "❌ Git не установлен. Установите Git: https://git-scm.com/"
    exit 1
fi

# Инициализация репозитория
if [ ! -d ".git" ]; then
    echo "📦 Инициализация Git репозитория..."
    git init
else
    echo "✅ Git репозиторий уже инициализирован"
fi

# Настройка пользователя (если не настроено)
if [ -z "$(git config user.name)" ]; then
    echo ""
    echo "Настройка Git пользователя:"
    read -p "Введите ваше имя: " git_name
    git config user.name "$git_name"
fi

if [ -z "$(git config user.email)" ]; then
    read -p "Введите ваш email: " git_email
    git config user.email "$git_email"
fi

echo ""
echo "✅ Git пользователь: $(git config user.name) <$(git config user.email)>"
echo ""

# Добавление файлов
echo "📝 Добавление файлов..."
git add .

# Проверка статуса
echo ""
echo "📊 Статус репозитория:"
git status --short | head -20

echo ""
read -p "Создать первый коммит? (y/n): " -n 1 -r
echo ""

if [[ $REPLY =~ ^[Yy]$ ]]; then
    git commit -m "Initial commit: PsyAnketa - психологическое анкетирование

- Расширенная анкета с 40+ вопросами
- Определение типа личности
- Анализ психологического состояния
- Генерация рекомендаций
- Сохранение в БД (Prisma + SQLite)
- Экспорт в PDF
- Панель психолога"
    
    echo ""
    echo "✅ Первый коммит создан!"
    echo ""
    echo "📋 Следующие шаги:"
    echo "1. Создайте репозиторий на GitHub: https://github.com/new"
    echo "2. Выполните команды, которые GitHub покажет после создания репозитория:"
    echo "   git remote add origin https://github.com/YOUR_USERNAME/psy-anketa.git"
    echo "   git branch -M main"
    echo "   git push -u origin main"
    echo ""
    echo "📖 Подробная инструкция: см. GITHUB_SETUP.md"
else
    echo "Коммит не создан. Вы можете создать его позже командой:"
    echo "git commit -m 'Initial commit'"
fi

