# 🔐 Настройка GitHub через Cursor

Cursor имеет встроенную интеграцию с GitHub. Вот как настроить:

## Способ 1: Через интерфейс Cursor (Рекомендуется)

### Шаг 1: Откройте панель управления аккаунтом

1. В Cursor нажмите на **иконку аккаунта** в правом нижнем углу (или `Cmd + Shift + P`)
2. Выберите **"Sign in with GitHub"** или **"Account Settings"**
3. Следуйте инструкциям для авторизации через браузер

### Шаг 2: Авторизация через браузер

1. Cursor откроет браузер с запросом авторизации GitHub
2. Войдите в свой GitHub аккаунт
3. Разрешите Cursor доступ к вашему аккаунту
4. Вернитесь в Cursor - авторизация должна быть завершена

### Шаг 3: Создание репозитория через Cursor

1. Нажмите `Cmd + Shift + P` (или `Ctrl + Shift + P`)
2. Введите `Git: Publish to GitHub`
3. Выберите, хотите ли вы сделать репозиторий приватным или публичным
4. Cursor автоматически создаст репозиторий и запушит код

## Способ 2: Через GitHub CLI (gh)

Если у вас установлен GitHub CLI:

```bash
# Авторизация
gh auth login

# Следуйте инструкциям:
# 1. Выберите GitHub.com
# 2. Выберите HTTPS или SSH
# 3. Выберите способ авторизации (браузер или токен)
# 4. Разрешите доступ

# Создание репозитория
gh repo create psy-anketa --public --source=. --remote=origin --push
```

## Способ 3: Через командную строку (классический)

### 1. Создайте Personal Access Token

1. Перейдите на GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
2. Нажмите "Generate new token (classic)"
3. Название: `Cursor PsyAnketa`
4. Выберите права: `repo` (полный доступ к репозиториям)
5. Нажмите "Generate token"
6. **Скопируйте токен** (он показывается только один раз!)

### 2. Настройте Git

```bash
# Настройте пользователя (если еще не настроено)
git config user.name "Ваше Имя"
git config user.email "your.email@example.com"

# Настройте credential helper для macOS
git config --global credential.helper osxkeychain
```

### 3. Создайте репозиторий на GitHub

1. Перейдите на https://github.com/new
2. Название: `psy-anketa`
3. Описание: `Онлайн справочник-анкетирование для психолога`
4. Выберите Public или Private
5. **НЕ** ставьте галочки на инициализацию
6. Нажмите "Create repository"

### 4. Подключите и запушьте

```bash
# Добавьте remote
git remote add origin https://github.com/YOUR_USERNAME/psy-anketa.git

# Переименуйте ветку
git branch -M main

# Запушьте код (GitHub попросит логин и токен вместо пароля)
git push -u origin main
```

При запросе пароля:
- **Username:** ваш GitHub username
- **Password:** вставьте Personal Access Token (не пароль!)

## Проверка настройки

```bash
# Проверить remote
git remote -v

# Проверить статус
git status

# Проверить авторизацию GitHub (если установлен gh)
gh auth status
```

## Полезные команды Cursor для Git

- `Cmd + Shift + P` → `Git: Clone` - клонировать репозиторий
- `Cmd + Shift + P` → `Git: Push` - отправить изменения
- `Cmd + Shift + P` → `Git: Pull` - получить изменения
- `Cmd + Shift + P` → `Git: Commit` - создать коммит
- `Cmd + Shift + P` → `Git: Publish Branch` - опубликовать ветку

## Решение проблем

### Ошибка авторизации
```bash
# Очистите сохраненные credentials
git credential-osxkeychain erase
host=github.com
protocol=https
[Press Enter twice]

# Или удалите из Keychain Access:
# Keychain Access → поиск "github.com" → удалите старые записи
```

### Ошибка "remote origin already exists"
```bash
git remote remove origin
git remote add origin https://github.com/YOUR_USERNAME/psy-anketa.git
```

### Изменить URL remote
```bash
git remote set-url origin https://github.com/YOUR_USERNAME/psy-anketa.git
```

## Безопасность

⚠️ **Важно:**
- Никогда не коммитьте `.env` файлы с секретами
- Используйте `.gitignore` для исключения чувствительных данных
- Personal Access Tokens храните в безопасном месте
- Регулярно обновляйте токены

## Следующие шаги

После настройки GitHub:
1. ✅ Код будет в облаке
2. ✅ Можно работать с разных устройств
3. ✅ История изменений сохраняется
4. ✅ Можно приглашать коллабораторов
5. ✅ GitHub Actions создает автоматические архивы

