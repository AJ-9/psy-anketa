#!/bin/bash
# Временный helper для Git credentials
# Используется только для первоначальной настройки

echo "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"

