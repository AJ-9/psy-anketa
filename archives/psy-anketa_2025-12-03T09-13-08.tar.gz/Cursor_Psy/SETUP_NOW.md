# 🚀 Настройка GitHub ПРЯМО СЕЙЧАС

## Ваш токен получен! Выполните эти команды:

### 1. Создайте репозиторий на GitHub

Откройте в браузере: **https://github.com/new**

Заполните:
- **Repository name:** `psy-anketa`
- **Description:** `Онлайн справочник-анкетирование для психолога`
- Выберите **Public** или **Private**
- **НЕ** ставьте галочки
- Нажмите **"Create repository"**

### 2. Узнайте ваш GitHub username

Откройте: **https://github.com/settings/profile**

Ваш username будет вверху (например: `alikbidzhiev`)

### 3. Выполните эти команды в терминале:

```bash
cd /Users/alikbidzhiev/Documents/Cursor_Psy

# Создайте коммит (если еще не создан)
git add .
git commit -m "Initial commit: PsyAnketa"

# Настройте remote (ЗАМЕНИТЕ YOUR_USERNAME на ваш GitHub username!)
git remote remove origin 2>/dev/null
git remote add origin https://YOUR_TOKEN@github.com/YOUR_USERNAME/psy-anketa.git

# Переименуйте ветку
git branch -M main

# Запушьте код
git push -u origin main
```

### 4. Готово! 🎉

Ваш репозиторий будет доступен по адресу:
```
https://github.com/YOUR_USERNAME/psy-anketa
```

## ⚠️ После успешного push - обезопасьте токен:

```bash
# Удалите токен из URL (он останется в истории Git, но не будет в будущих командах)
git remote set-url origin https://github.com/YOUR_USERNAME/psy-anketa.git

# Настройте credential helper
git config credential.helper osxkeychain
```

При следующем push Git спросит пароль - введите **токен** (не пароль от GitHub!)

## Быстрый способ - используйте скрипт:

```bash
cd /Users/alikbidzhiev/Documents/Cursor_Psy
./setup-github.sh
```

Скрипт автоматически:
- Получит ваш username
- Создаст репозиторий
- Настроит remote
- Запушит код

---

**Важно:** Токен чувствительная информация. После настройки не делитесь им и не коммитьте в репозиторий!

