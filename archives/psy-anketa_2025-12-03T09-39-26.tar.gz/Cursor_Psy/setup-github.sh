#!/bin/bash

# Скрипт для настройки GitHub с токеном

set -e  # Остановка при ошибке

TOKEN="YOUR_GITHUB_TOKEN_HERE"
REPO_NAME="psy-anketa"

echo "🔧 Настройка GitHub репозитория..."
echo ""

# Проверка наличия curl
if ! command -v curl &> /dev/null; then
    echo "❌ Ошибка: curl не установлен. Установите curl."
    exit 1
fi

# Проверка наличия git
if ! command -v git &> /dev/null; then
    echo "❌ Ошибка: git не установлен. Установите git."
    exit 1
fi

# Получаем username
echo "📡 Шаг 1: Получение информации о пользователе GitHub..."
API_RESPONSE=$(curl -s -H "Authorization: token $TOKEN" -H "Accept: application/vnd.github.v3+json" https://api.github.com/user 2>&1)

# Проверяем на ошибки
if echo "$API_RESPONSE" | grep -q "Bad credentials\|Unauthorized\|Not Found"; then
    echo "❌ Ошибка: Неверный токен или токен истек."
    echo "   Проверьте токен на GitHub: https://github.com/settings/tokens"
    exit 1
fi

# Пробуем разные способы извлечения username
USERNAME=$(echo "$API_RESPONSE" | python3 -c "import sys, json; print(json.load(sys.stdin)['login'])" 2>/dev/null)

if [ -z "$USERNAME" ]; then
    USERNAME=$(echo "$API_RESPONSE" | grep -o '"login":"[^"]*' | cut -d'"' -f4)
fi

if [ -z "$USERNAME" ]; then
    USERNAME=$(echo "$API_RESPONSE" | grep -oP '"login":\s*"\K[^"]+')
fi

if [ -z "$USERNAME" ]; then
    echo "❌ Ошибка: не удалось получить username."
    echo "   Ответ API: $API_RESPONSE"
    echo "   Проверьте токен: curl -H \"Authorization: token $TOKEN\" https://api.github.com/user"
    exit 1
fi

echo "✅ Пользователь: $USERNAME"
echo ""

# Проверяем, существует ли репозиторий
echo "🔍 Шаг 2: Проверка существования репозитория..."
REPO_EXISTS=$(curl -s -o /dev/null -w "%{http_code}" -H "Authorization: token $TOKEN" -H "Accept: application/vnd.github.v3+json" https://api.github.com/repos/$USERNAME/$REPO_NAME 2>/dev/null)

if [ "$REPO_EXISTS" = "200" ]; then
    echo "✅ Репозиторий уже существует: https://github.com/$USERNAME/$REPO_NAME"
else
    echo "📦 Создание репозитория $REPO_NAME..."
    RESPONSE=$(curl -s -w "\n%{http_code}" -X POST \
        -H "Authorization: token $TOKEN" \
        -H "Accept: application/vnd.github.v3+json" \
        https://api.github.com/user/repos \
        -d "{\"name\":\"$REPO_NAME\",\"description\":\"Онлайн справочник-анкетирование для психолога\",\"private\":false}" 2>/dev/null)
    
    HTTP_CODE=$(echo "$RESPONSE" | tail -n1)
    
    if [ "$HTTP_CODE" = "201" ] || [ "$HTTP_CODE" = "200" ]; then
        echo "✅ Репозиторий создан: https://github.com/$USERNAME/$REPO_NAME"
    else
        echo "❌ Ошибка при создании репозитория. HTTP код: $HTTP_CODE"
        echo "   Ответ: $(echo "$RESPONSE" | head -n-1)"
        exit 1
    fi
fi
echo ""

# Настраиваем remote
echo "🔗 Шаг 3: Настройка remote..."
git remote remove origin 2>/dev/null || true
git remote add origin "https://$TOKEN@github.com/$USERNAME/$REPO_NAME.git"
echo "✅ Remote настроен: origin -> https://github.com/$USERNAME/$REPO_NAME.git"
echo ""

# Убеждаемся, что мы на ветке main
git branch -M main 2>/dev/null || true

# Создаем коммит если его нет
if ! git log --oneline -1 > /dev/null 2>&1; then
    echo "📝 Создание первого коммита..."
    git add . || true
    git commit -m "Initial commit: PsyAnketa - психологическое анкетирование

- Расширенная анкета с 40+ вопросами
- Определение типа личности
- Анализ психологического состояния
- Генерация рекомендаций
- Сохранение в БД (Prisma + SQLite)
- Экспорт в PDF
- Панель психолога" || echo "⚠️  Коммит уже существует или нет изменений"
else
    echo "✅ Коммит уже существует"
fi
echo ""

# Пушим код
echo "🚀 Шаг 4: Отправка кода на GitHub..."
set +e  # Разрешаем ошибки для проверки результата
GIT_TERMINAL_PROMPT=0 git push -u origin main 2>&1
PUSH_RESULT=$?
set -e

if [ $PUSH_RESULT -eq 0 ]; then
    echo ""
    echo "🎉 УСПЕШНО! Репозиторий доступен по адресу:"
    echo "   👉 https://github.com/$USERNAME/$REPO_NAME"
    echo ""
    echo "⚠️  ВАЖНО: Токен сохранен в remote URL. Для безопасности выполните:"
    echo ""
    echo "   git remote set-url origin https://github.com/$USERNAME/$REPO_NAME.git"
    echo "   git config credential.helper osxkeychain"
    echo ""
    echo "   При следующем push введите токен в качестве пароля."
    echo ""
else
    echo ""
    echo "❌ Ошибка при отправке кода (код: $PUSH_RESULT)"
    echo ""
    echo "Возможные причины:"
    echo "  - Репозиторий уже содержит код (попробуйте: git pull origin main --allow-unrelated-histories)"
    echo "  - Проблемы с сетью"
    echo "  - Неверный токен или недостаточно прав"
    echo ""
    echo "Проверьте remote:"
    echo "  git remote -v"
    echo ""
    exit 1
fi

