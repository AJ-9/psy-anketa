# 🔧 Исправление проблемы с токеном

GitHub заблокировал push, потому что токен был в файлах. Я удалил токен из всех файлов.

## Выполните эти команды:

```bash
cd /Users/alikbidzhiev/Documents/Cursor_Psy

# Добавьте изменения
git add -A

# Создайте коммит
git commit -m "Remove GitHub token from files for security"

# Запушьте
git push -u origin main
```

После этого код должен успешно отправиться на GitHub!

## Ваш репозиторий:

https://github.com/AJ-9/psy-anketa

---

**Важно:** Токен теперь удален из всех файлов. Если нужно использовать скрипты, вставьте токен вручную в переменную `TOKEN` в начале скрипта.

