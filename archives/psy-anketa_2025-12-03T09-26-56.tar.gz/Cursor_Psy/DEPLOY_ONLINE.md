# 🌐 Развертывание проекта онлайн

Отличная идея! Вместо локального запуска можно развернуть проект онлайн.

## Способ 1: Vercel (РЕКОМЕНДУЕТСЯ для Next.js) ⭐

Vercel создан командой Next.js и идеально подходит для наших проектов.

### Шаг 1: Зарегистрируйтесь на Vercel

1. Откройте: **https://vercel.com/**
2. Нажмите **"Sign Up"**
3. Выберите **"Continue with GitHub"**
4. Авторизуйтесь через GitHub

### Шаг 2: Импортируйте проект

1. Нажмите **"Add New Project"**
2. Выберите репозиторий **`AJ-9/psy-anketa`**
3. Vercel автоматически определит Next.js
4. Нажмите **"Deploy"**

### Шаг 3: Настройте переменные окружения (если нужно)

Vercel автоматически настроит всё, но если нужны переменные:
- Settings → Environment Variables

### Шаг 4: Готово! 🎉

Ваш проект будет доступен по адресу:
```
https://psy-anketa.vercel.app
```
(или ваш кастомный домен)

---

## Способ 2: Netlify

1. Откройте: **https://www.netlify.com/**
2. Sign Up через GitHub
3. Add new site → Import from Git
4. Выберите репозиторий
5. Build settings:
   - Build command: `npm run build`
   - Publish directory: `.next`
6. Deploy

---

## Способ 3: Railway

1. Откройте: **https://railway.app/**
2. Sign Up через GitHub
3. New Project → Deploy from GitHub
4. Выберите репозиторий
5. Railway автоматически определит Next.js

---

## Способ 4: Render

1. Откройте: **https://render.com/**
2. Sign Up через GitHub
3. New → Web Service
4. Connect GitHub репозиторий
5. Build Command: `npm install && npx prisma generate && npm run build`
6. Start Command: `npm start`

---

## Что нужно настроить для БД:

Для SQLite в продакшене лучше использовать PostgreSQL:

1. **Vercel:** Используйте Vercel Postgres (бесплатный план)
2. **Railway:** Автоматически предоставляет PostgreSQL
3. **Render:** Можно подключить PostgreSQL

Или можно использовать внешний сервис БД:
- **Supabase** (бесплатный PostgreSQL)
- **PlanetScale** (бесплатный MySQL)
- **Neon** (бесплатный PostgreSQL)

---

## Рекомендация:

**Используйте Vercel** - это самый простой способ для Next.js проектов:
- ✅ Автоматический деплой при каждом push в GitHub
- ✅ Бесплатный SSL сертификат
- ✅ Глобальный CDN
- ✅ Автоматические preview для каждого PR
- ✅ Простая интеграция с GitHub

---

**После деплоя ваш проект будет доступен по ссылке 24/7!**

