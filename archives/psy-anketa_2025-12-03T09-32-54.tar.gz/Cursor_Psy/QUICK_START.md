# 🚀 Быстрый старт - Запуск проекта онлайн

## Шаг 1: Установка Node.js

Если Node.js не установлен, установите его:

### macOS:
```bash
# Через Homebrew (рекомендуется)
brew install node

# Или скачайте с официального сайта
# https://nodejs.org/
```

### Проверка установки:
```bash
node --version
npm --version
```

Должны быть версии Node.js 18+ и npm 9+

## Шаг 2: Установка зависимостей

```bash
cd /Users/alikbidzhiev/Documents/Cursor_Psy
npm install
```

Это установит все необходимые пакеты (Next.js, React, Prisma и т.д.)

## Шаг 3: Настройка базы данных

```bash
# Генерируем Prisma Client
npx prisma generate

# Создаем миграцию БД
npx prisma migrate dev --name init
```

## Шаг 4: Запуск проекта

```bash
npm run dev
```

После запуска вы увидите:
```
  ▲ Next.js 14.x.x
  - Local:        http://localhost:3000
  - Network:      http://192.168.x.x:3000
```

## Шаг 5: Откройте в браузере

Откройте браузер и перейдите по адресу:

**http://localhost:3000**

## Что вы увидите:

1. **Главная страница** (`/`) - приветствие и кнопка "Начать анкетирование"
2. **Анкета** (`/questionnaire`) - прохождение анкеты
3. **Результаты** (`/results`) - результаты анализа после завершения анкеты
4. **Панель психолога** (`/admin`) - история всех анкет (доступна с главной страницы)

## Остановка сервера

Нажмите `Ctrl + C` в терминале, где запущен сервер.

## Возможные проблемы:

### Порт 3000 занят
```bash
# Используйте другой порт
PORT=3001 npm run dev
```

### Ошибки с Prisma
```bash
# Пересоздайте БД
rm -f prisma/dev.db
npx prisma migrate dev --name init
```

### Ошибки с зависимостями
```bash
# Очистите и переустановите
rm -rf node_modules package-lock.json
npm install
```

## Структура URL:

- `http://localhost:3000` - Главная страница
- `http://localhost:3000/questionnaire` - Анкета
- `http://localhost:3000/results` - Результаты (после завершения анкеты)
- `http://localhost:3000/admin` - Панель психолога

