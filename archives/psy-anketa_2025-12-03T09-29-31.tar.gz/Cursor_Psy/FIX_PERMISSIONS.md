# 🔧 Исправление прав доступа

Если вы получили ошибку `permission denied`, выполните:

```bash
chmod +x setup-github.sh
```

Затем снова запустите:

```bash
./setup-github.sh
```

## Альтернатива - запуск через bash:

```bash
bash setup-github.sh
```

Или:

```bash
sh setup-github.sh
```

Эти команды работают без прав на выполнение.

